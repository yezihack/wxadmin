<?php
namespace Org\Weixin;
class WeixinRedpack
{
	public $appId = '';//'wx426b3015555a46be'; //绑定支付的APPID（必须配置）
	//public $appsecret = '';//'01c6d59a3f9024db6336662ac95c8e74'; //公众帐号secert（仅JSAPI支付的时候需要配置）
	public $mchId = '';//'1242066402'; //商户号（必须配置）
	public $mchApi_Key = "";//商户APIKey

	public $sslcert_path = '';//证书路径,注意应该填写绝对路径
	public $sslkey_path = '';//证书路径,注意应该填写绝对路径

	public function __construct(){
		$this->appId = C('wx_appid');
		//$this->appsecret = C('wx_secret');
		$this->mchId = C('wx_mchId');
		$this->mchApi_Key  =  C('wx_mchApiKey');
		$this->sslcert_path = C('cacheRoot')."/apiclient_cert.pem";
		$this->sslkey_path = C('cacheRoot')."/apiclient_key.pem";

	}


	public function sendredpack($args=array())
	{
		$url = "https://api.mch.weixin.qq.com/mmpaymkttransfers/sendredpack";
		$args_wx = array();
		$args_wx['nonce_str']     = self::getNonceStr();//随机字符串
		$args_wx['mch_billno']    = $this->makeBillno();//商户订单号
		$args_wx['mch_id']        = $this->mchId;//商户号
		$args_wx['wxappid']       = $this->appId;//公众账号appid（发红包的）
		//$args_wx['nick_name']     = $args['nick_name'];//'急聘科技';//提供方名称
		$args_wx['send_name']     = $args['send_name'];//'急聘科技';//商户名称
		$args_wx['re_openid']     = $args['re_openid'];//接受收红包的用户
		$args_wx['total_amount']  = $args['total_amount'];//付款金额，单位分
		//$args_wx['min_value']     = $args['money'];//最小红包金额，单位分
		//$args_wx['max_value']     = $args['money'];//最大红包金额，单位分（ 最小金额等于最大金额： min_value=max_value =total_amount）
		$args_wx['total_num']     = 1;//红包发放总人数
		$args_wx['wishing']       = $args['wishing'];//红包祝福语
		$args_wx['client_ip']     = $this->gethost();//调用接口的机器Ip地址
		$args_wx['act_name']      = $args['act_name'];//活动名称
		$args_wx['remark']        = $args['remark'];//备注
		//$args_wx['logo_imgurl']   = $args['logo_imgurl'];//商户logo的url
		//$args_wx['share_content'] = $args['share_content'];//分享文案
		//$args_wx['share_url']     = $args['share_url'];//分享链接
		//$args_wx['share_imgurl']  = $args['share_imgurl'];//分享的图片

		$sign = $this->makeSign($args_wx);
		$args_wx['sign'] = $sign;//签名
		$xml = $this->fromArray($args_wx);
		//var_dump($xml);
		$dataXml = $this->curl_post_ssl($url,$xml);
		$data = $this->fromXml($dataXml);

		$returnData = array('status'=>'0','msg'=>'未解析出返回值','data'=>$data);
		if(is_array($data))
		{
			if(array_key_exists("return_code",$data) && $data['return_code'] =="SUCCESS" && $data['result_code']=="SUCCESS")
			{
				$returnData['status'] = 1;
				$returnData['msg'] = "红包发送成功";

			}
			else
			{
				$returnData['status'] = -1;
				$returnData['msg'] = "红包发送失败";
			}

		}
		return $returnData;

	}
	function curl_post_ssl($url, $vars, $second=30,$aHeader=array())
	{
		$ch = curl_init();
		//超时时间
		curl_setopt($ch,CURLOPT_TIMEOUT,$second);
		//设置header
		//curl_setopt($ch, CURLOPT_HEADER, true);
		//结果为字符串输出到屏幕上
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
		//这里设置代理，如果有的话
		//curl_setopt($ch,CURLOPT_PROXY, '10.206.30.98');
		//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);

		//以下两种方式需选择一种

		//第一种方法，cert 与 key 分别属于两个.pem文件
		//默认格式为PEM，可以注释
		//curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLCERT,$this->sslcert_path);
		//默认格式为PEM，可以注释
		//curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
		curl_setopt($ch,CURLOPT_SSLKEY,$this->sslkey_path);

		//第二种方式，两个文件合成一个.pem文件
		//curl_setopt($ch,CURLOPT_SSLCERT,getcwd().'/all.pem');

		if( count($aHeader) >= 1 ){
			curl_setopt($ch, CURLOPT_HTTPHEADER, $aHeader);
		}

		curl_setopt($ch,CURLOPT_POST, 1);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$vars);
		$data = curl_exec($ch);
		//var_dump(curl_error($ch));
		//var_dump($data);

		//var_dump($data);die();
		if($data){
			curl_close($ch);
			return $data;
		}
		else {
			$error = curl_errno($ch);
			echo "call faild, errorCode:$error\n";
			curl_close($ch);
			return false;
		}
	}

	/**
	 *
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	public static function getNonceStr($length = 32)
	{
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);
		}
		return $str;
	}

	/**
	 * 格式化参数格式化成url参数
	 */
	public function toUrlParams($args)
	{
		$buff = "";
		foreach ($args as $k => $v)
		{
			if($k != "sign" && $v != "" && !is_array($v)){
				$buff .= $k . "=" . $v . "&";
			}
		}

		$buff = trim($buff, "&");
		return $buff;
	}

	/**
	 * 生成签名
	 * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
	 */
	public function makeSign($args)
	{
		//签名步骤一：按字典序排序参数
		ksort($args);
		$string = $this->ToUrlParams($args);
		//签名步骤二：在string后加入KEY
		$string = $string . "&key=".$this->mchApi_Key;
		//签名步骤三：MD5加密
		$string = md5($string);
		//签名步骤四：所有字符转为大写
		$result = strtoupper($string);
		return $result;
	}
	/**
	 * 生成商户订单号
	 * @return string
	 */
	public function makeBillno()
	{
		$ymd = date('Ymd');
		$rand10 = date('mdHis');
		$str = $this->mchId.$ymd.$rand10;
		return $str;
	}
	/**
	 * 将xml转为array
	 * @param string $xml
	 * @throws WxPayException
	 */
	public function fromXml($xml)
	{
		if(!$xml){
			throw new Exception("xml数据异常！");
		}
		//将XML转为array
		$data_array = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
		return $data_array;
	}
	/**
	 * 将array转换成xml
	 * @param unknown_type $arr
	 */
	public function fromArray($arr)
	{
		if(empty($arr))
		{
			return "";
		}
		$xml = "<xml>";
		foreach($arr as $key=>$val)
		{
			if (preg_match("/[\x7f-\xff]/", $val))
			{
				$xml .= "<{$key}><![CDATA[{$val}]]></{$key}>";
			}
			else
			{
				$xml .= "<{$key}>{$val}</{$key}>";
			}

		}
		$xml .= "</xml>";
		return $xml;
	}
	/**
	 * 获得服务器ip地址
	 */
	public function gethost()
	{
		return gethostbyname($_SERVER['SERVER_NAME']);
	}

}