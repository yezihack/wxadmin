<?php
namespace Org\Weixin;
class WeixinUtil
{
	/**
	 * 获得微信授权的Url
	 * Enter description here ...
	 * @param unknown_type $state
	 * @param unknown_type $returnUrl
	 * @param $scope snsapi_base 只获得openId授权方式；snsapi_userinfo：获得用户信息的授权方式
	 */
	public function getAuthUrl($state,$returnUrl="",$scope="snsapi_base")
	{
		if(empty($returnUrl))
		{
			$returnUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		}
		$jssdk = new \Org\Weixin\Jssdk();
		$appId = $jssdk->appId;
		
		$url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appId}&redirect_uri={$returnUrl}&response_type=code&scope={$scope}&state={$state}#wechat_redirect";
	    return $url;
	}
	/**
	 * 通过code换取网页授权access_token
	 * 获取到网页授权access_token的同时，也获取到了openid
	 * {
	   "access_token":"ACCESS_TOKEN",
	   "expires_in":7200,
	   "refresh_token":"REFRESH_TOKEN",
	   "openid":"OPENID",
	   "scope":"SCOPE",
	   "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	     }
	 * Enter description here ...
	 * @param unknown_type $code
	 */
	public function getTokenByCode($code="")
	{
		if(empty($code))
		{
			return array();
		}
		
		$jssdk = new \Org\Weixin\Jssdk();
		$appId = $jssdk->appId;
		$secret = $jssdk->appSecret;
		$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$appId}&secret={$secret}&code={$code}&grant_type=authorization_code";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
		$dataJson = curl_exec($ch);
		curl_close($ch);
		$data = json_decode($dataJson,true);
		return $data;
		//return isset($data['openid']) ? $data['openid'] : '';
	}
	/**
	 * 获得userInfo--网页授权的方式获得用户信息，注意$access_token 也是网页授权获得的
	 * Enter description here ...
	 * @param unknown_type $access_token
	 * @param unknown_type $openId
	 */
   public function getUserInfo($access_token="",$openId="")
   {
		if(empty($access_token) || empty($openId))
		{
			return array();
		}

		$url = "https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$openId}&lang=zh_CN";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
		$dataJson = curl_exec($ch);
		curl_close($ch);
		$data = json_decode($dataJson,true);
		return $data;

	}
    //根据用户的OpenID来获取用户基本信息
    public function getUserInfoById($access_token="",$openId="")
    {
        if(empty($access_token) || empty($openId))
        {
            return array();
        }

        $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$openId}&lang=zh_CN";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
        $dataJson = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($dataJson,true);
        return $data;
    }

}