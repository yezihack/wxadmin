<?php
# 微信接口类（前、后台、插件公用）
namespace Org\Weixin;
class WxApi
{
    private $appid;
    private $secret;
    private $scope;

    function __construct()
    {
        $this->appid = C('wx_appid');
        $this->secret = C('wx_secret');
        $this->scope = C('wx_scope');
    }

    # weixin/weixin_api/ 目录里封装的类--获取token
    public function getToken(){
        //测试返回固定 token 2018年1月27日08:32:13
        //return "6_heADRLb_mMgbvadOq2OvpEKVsC_I37tQoikgvqME1xE6_M2RGe-1k9GWFz2XoBuHOjw3Je9SfuakbKQhqM_aZB7a5KWSRxi2vIbKVC4xQFdMhG7qG_mu2tGL6IcPqYbBw_vbvjOkmYEvrdUVHVXiAEAPDF";
        require_once dirname(dirname(__FILE__)).'/Weixin/Jssdk.class.php';
        $jssdk = new JSSDK($this->appid, $this->secret);
        $access_token = $jssdk->getAccessToken();
        return $access_token;
    }

    # 公用的GET接口调用工具：
    function getInterface($url){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
        $dataJson = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($dataJson,true);
        return $data;
    }

    # 公用的POST接口调用工具：
    function postInterface($wx_url,$data,$header=""){

        $ch = curl_init();
        //设置header
        if(!empty($header))
        {
            curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
        }
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL,$wx_url); // url
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // json数据
        $dataJson = curl_exec($ch); // 返回值
        curl_close($ch);
        $data = json_decode($dataJson,true);
        return $data;
    }

}