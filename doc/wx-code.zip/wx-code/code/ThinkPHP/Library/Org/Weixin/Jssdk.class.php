<?php
namespace Org\Weixin;
class Jssdk{
  public $appId;
  public $appSecret;
//  public $cachePathFile;
  public function __construct(){
	    $this->appId = C('wx_appid');
	    $this->appSecret = C('wx_secret');
//	    $this->id = MrJobs_Config::$MAIN['id'];
	    $this->cachePathFile = C('cachePathFile');
  }

  public function getSignPackage($url='') {
    $jsapiTicket = $this->getJsApiTicket();
    if(empty($url))
    {
    	$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    }
    $timestamp = time();
    $nonceStr = $this->createNonceStr();

    // 这里参数的顺序要按照 key 值 ASCII 码升序排序
    $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

    $signature = sha1($string);

    $signPackage = array(
      "appId"     => $this->appId,
      "nonceStr"  => $nonceStr,
      "timestamp" => $timestamp,
      "url"       => $url,
      "signature" => $signature,
      "rawString" => $string
    );
    return $signPackage;
  }

  private function createNonceStr($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }

  public function getJsApiTicket() {
  	$jsapi_ticket_path = $this->cachePathFile."jsapi_ticket.json";
    // jsapi_ticket 应该全局存储与更新，以下代码以写入到文件中做示例
    $data = json_decode(file_get_contents($jsapi_ticket_path));
    if ($data->expire_time < time()) {
      $accessToken = $this->getAccessToken();
      // 如果是企业号用以下 URL 获取 ticket
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
      $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
      $weixinData = $this->httpGet($url);
      $res = json_decode($weixinData);
      $ticket = $res->ticket;
      if ($ticket) {
        $data->expire_time = time() + 7000;
        $data->jsapi_ticket = $ticket;
        $fp = fopen($jsapi_ticket_path, "w");
        fwrite($fp, json_encode($data));
        fclose($fp);
      }
    } else {
      $ticket = $data->jsapi_ticket;
    }

    return $ticket;
  }

  public function getAccessToken() {
  	$access_token_path = $this->cachePathFile.'access_token.json';
    // access_token 应该全局存储与更新，以下代码以写入到文件中做示例
    $data = json_decode(file_get_contents($access_token_path));
    if ($data->expire_time < time()) {
      // 如果是企业号用以下URL获取access_token
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->appId&corpsecret=$this->appSecret";
      $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
      $weixinData = $this->httpGet($url);
      $res = json_decode($weixinData);
      $access_token = $res->access_token;


      if ($access_token) {
        $data->expire_time = time() + 7000;
        $data->access_token = $access_token;
        $fp = fopen($access_token_path, "w");
        fwrite($fp, json_encode($data));
        fclose($fp);
      }
    } else {
      $access_token = $data->access_token;
    }
    return $access_token;
  }

  public function httpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_URL, $url);

    $res = curl_exec($curl);
    curl_close($curl);

    return $res;
  }

  # 公用的POST接口调用工具：
  public function postInterface($wx_url,$data){

  	$ch = curl_init();
  	curl_setopt($ch, CURLOPT_HEADER, FALSE);
  	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
  	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  	curl_setopt($ch, CURLOPT_URL,$wx_url); // url
  	curl_setopt($ch, CURLOPT_POST, TRUE);
  	curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // json数据
  	$dataJson = curl_exec($ch); // 返回值
  	curl_close($ch);
  	$data = json_decode($dataJson,true);
  	return $data;
  }
//获取微信用户的信息(openid.unineid等)====================================
    public function get_uinfo($type='base')
    {
        //判断是否是微信打开
        $isWeixin = $this->isWeixin();
        if ($isWeixin) {
            //微信获取openid跳转检查验证
            return $this->weixinCheck($type);
        } else {
            exit("请使用微信打开");
        }
        //return $this->weixinCheck($type);
    }
    //1.判断是否是微信打开
    public static function isWeixin()
    {
        $isweixin = false;
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        if (strpos($user_agent, 'MicroMessenger') !== false) {
            $isweixin = true;
        }
        return $isweixin;
    }
    //2.微信获取openid跳转检查验证
    public function weixinCheck($type,$is_only_openid=false)
    {
        if (!empty($_SESSION['weixin_user_info'])) {
            return $_SESSION['weixin_user_info'];
        }
        $res = $this->wx_getUserInfo($type,$is_only_openid);
        return $res;
    }
    //3.获取来访用户的基本信息
    /**
     * 
     * @param unknown $type
     * @param unknown $is_only_openid 仅是获得微信的openid
     * @return unknown
     */
    function wx_getUserInfo($type,$is_only_openid=false)
    {

        $scope = 'snsapi_'.$type;
        $state = '1234';
        $redirect_uri = urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
        $weixinutil_obj = new \Org\Weixin\WeixinUtil();
        // 跳转到微信接口拿到code和state值：
        if(empty($_GET['code']) && empty($_GET['state']) ){
            // 第一步：用户同意授权，获取code
            $url  = $weixinutil_obj->getAuthUrl($state,$redirect_uri,$scope);
            header('location:'.$url);
            exit();
        }
        // 通过code换取access_token授权：
        $res = $weixinutil_obj->getTokenByCode($_GET['code']);
        if($scope=='snsapi_base'){
        	
        	if($is_only_openid)
        	{
        		$result = $res['openid'];
        		$_SESSION['weixin_user_info']['openid'] = $res['openid'];
        	}
        	else 
        	{
        		//获取用户的UnionID：
        		$access_token2 =$this->getAccessToken();//接口凭证（注意：不是网页授权的接口凭证）
        		$result = $weixinutil_obj->getUserInfoById($access_token2,$res['openid']);
        		$_SESSION['weixin_user_info'] = $result;
        	}
          
        }else if($scope=='snsapi_userinfo'){
            $result = $weixinutil_obj->getUserInfo($res['access_token'],$res['openid']);
//            $_SESSION['weixin_user_info'] = $result;
        }
        //返回数据，为写入数据库做准备
        return $result;
    }

//==============================================================
//惠普微信账号的相关判断方法====================================
    //获取惠普的接口凭证token
    public function get_token()
    {
        $key=$this->check_key();
//        $url="http://max.mrjobs.com/api.php?class=hp_weixin&method=get_hp_token&key=a7bdb4a8d";
        $url="http://".C('TOKEN_URL_HOST')."/api.php?class=hp_weixin&method=get_hp_token&key=".$key;
        $data=$this->httpGet($url);
        $data = json_decode($data,true);
        $token = $data['data'];
        return $token;
    }
    public function check_key()
    {
//        API_PRE_KEY = 'pincn_bj';
        $host=C('TOKEN_URL_HOST');
        $key=md5(API_PRE_KEY.$host);
        $key=substr($key,3,9);
        return $key;
    }

    //====根据openid 以及惠普的token，获取用户信息，用来判断是否关注了惠普公众号
    public function is_concern($openid){
        //获取token
        $token = $this->get_token();
        $weixinutil_obj = new \Org\Weixin\WeixinUtil();
        $result = $weixinutil_obj->getUserInfoById($token,$openid);
        return $result;
    }
//结束======================
    /**
     *
     * @param 密码加密 $data
     */
    function encrypt($data)
    {
        $key = md5("xiaoguangqazwsxedc159852");
        $x  = 0;
        $len = strlen($data);
        $l  = strlen($key);
        $char = '';
        for($i = 0; $i < $len; $i++)
        {
            if($x == $l)
            {
                $x = 0;
            }
            $char .= $key{$x};
            $x++;
        }
        $str = '';
        for($i = 0; $i < $len; $i++)
        {
            $str .= chr(ord($data{$i}) + (ord($char{$i})) % 256);
        }
        return base64_encode($str);
    }

    function decrypt($data)
    {
        $key = md5("xiaoguangqazwsxedc159852");
        $x = 0;
        $data = base64_decode($data);
        $len = strlen($data);
        $l = strlen($key);
        $char = '';
        for ($i = 0; $i < $len; $i++)
        {
            if ($x == $l)
            {
                $x = 0;
            }
            $char .= substr($key, $x, 1);
            $x++;
        }
        $str = '';
        for ($i = 0; $i < $len; $i++)
        {
            if(ord(substr($data, $i, 1)) < ord(substr($char, $i, 1)))
            {
                $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
            }
            else
            {
                $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
            }
        }
        return $str;
    }

}
