<!DOCTYPE HTML>
<html lang="en-US">
<head>
<title>微信二维码设置</title>
<meta charset="UTF-8">
<meta name="keywords" content="">
<meta name="description" content="">
<link type="text/css" href="{{$Think.CSS_URL}}/reset.css" rel="stylesheet">
<link type="text/css" href="{{$Think.CSS_URL}}/public.css" rel="stylesheet">
<link type="text/css" href="{{$Think.CSS_URL}}/register.css" rel="stylesheet">
<script src="{{$Think.JS_URL}}/jquery.min.js" type="text/javascript"></script>
<script src="{{$Think.JS_URL}}/jquery.form.js" type="text/javascript"></script>
<script src="{{$Think.JS_URL}}/json.parse.js" type="text/javascript"></script>
<script type="text/javascript">
$(function(){
	$(".btn").click(function(){
		var isScene= $("#scene").val();
		var isDesc=$("#desc").val();
		//$(".input_div1 span,.input_div2 span").html("");
		//$(".btn").val('提交中...').attr('disabled','disabled');
		
		if(!isRegister(isScene)){
			$(".input_div1 span").html('<img src="{{$Think.IMG_URL}}/text_error.png"><font color=red>至少输入一位字母,数字或组合!</font>');
			$("#scene").focus();
			$(".btn").val('提交').removeAttr('disabled');
			return false;
		}else if(!isRegister(isDesc)){
			$(".input_div2 span").html('<img src="{{$Think.IMG_URL}}/text_error.png"><font color=red>不能为空!</font>');
			$("#desc").focus();
			$(".btn").val('提交').removeAttr('disabled');
			return false;
		}else{
			$("#registerForm").ajaxSubmit({
                    url: '/index.php/home/Qrcode',
                    type: "Post",
                    //成功返回
                    success: function (data) {
                    	var data=eval("("+data+")");
                        if(data.status == '200'){
							//success
                        	$("#scene").val('');
                        	$("#desc").val('');
                        	$("#urlStr").html(data.info);
                        }else
                        {
							alert(data.info);
                        }
                    }
				}
			)	
		}
				
	})
	
});

function isRegister(s){  
// 	var patrn=/^[a-zA-Z0-9]{1}([a-zA-Z0-9]|[._]){1,250}$/;  
// 	if (!patrn.exec(s)) return false
	return true
}

</script>
<style>
.input_div span{ background:#FFF;}
</style>
<!--[if IE 6]>
<script src="themes/js/DD_belatedPNG.js"  type="text/javascript"></script>
<script>DD_belatedPNG.fix('.png_bg');</script>
<![endif]-->
</head>
<body>
	<div class="register_content">
		<ul class="step_ul step1 clear">
			<li class="li1">微信二维码资料填写</li>
			<li class="li1">微信二维码URL</li>
		</ul>
		 <form name="registerForm" id='registerForm' action="" method="post" style="padding:60px 40px 88px 40px;font-family:Microsoft Yahei">
			<div class="div_form clear ">
				<label>渠道字符串：</label>
				<div class="input_div input_div1">
					<input id="scene" name="scene" type="text" placeholder="至少输入一位字母,数字或组合!" maxlength="24">
					<span></span>
				</div>
			</div>
			<div class="div_form clear ">
				<label>渠道备注说明：</label>
				<div class="input_div input_div2" >
					<input id="desc" name="desc"  type="text" placeholder="填写二维码渠道备注说明" maxlength="64">
					<span></span>
				</div>
			</div>
			<div class="div_form clear " hidden>
				<label></label>
				<div class="input_div input_div3">
					<input id="varcode" name="" type="text" maxlength="2">
					<span></span>
				</div>
			</div>
			<div class="div_form clear ">
				<label></label>
				<div class="input_div">
					<input id="btn" class="btn" type="button" value="提交" />
				</div>
			</div>
			
		</form>
		<div class="reg_login" style="width:200px;height:200px;border:none;">
			<!-- <p id="urlStr">此处显示生成的二维码URL,复制到新窗口打开即可显示二维码!</p> -->
			<textarea id="urlStr" style="width:200px;height:200px;overflow:scroll;resize:none;">此处显示生成的二维码URL!</textarea>
		</div>
		<div class="bg"></div>
	</div>
</body>
</html>
















