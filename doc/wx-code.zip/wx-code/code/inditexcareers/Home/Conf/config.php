<?php
return array(
	//'配置项'=>'配置值'
    /* 数据库设置 */
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  '192.168.99.191', // 服务器地址
    'DB_NAME'               =>  'inditexcareers',          // 数据库名
    'DB_USER'               =>  'rms',      // 用户名
    'DB_PWD'                =>  '123',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  '',    // 数据库表前缀

    'TMPL_TEMPLATE_SUFFIX'  =>  '.php',     // 默认模板文件后缀
    'TMPL_L_DELIM'          =>  '{{',            // 模板引擎普通标签开始标记
    'TMPL_R_DELIM'          =>  '}}',            // 模板引擎普通标签结束标记
    //开启日志
    'LOG_RECORD' => true, // 开启日志记录
    'LOG_LEVEL'  =>'EMERG,ALERT,CRIT,ERR', // 只记录EMERG ALERT CRIT ERR 错误

    //微信公众号配置
    'wx_scope'              =>'base',//'base',//微信授权方式'snsapi_base' 'snsapi_userinfo'
    'wx_appid'              =>'wxd321ebed686955c8',//'wx1ee3460a36ab4f42',//测试公众账号appid
    'wx_secret'             =>'185c3f5579e993c7a260481c30366d77',//'b16f81009ab7f50e28666440e96d1fe6',//测试号秘钥
    'check_token'           => "inditexcareers",
);