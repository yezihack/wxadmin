<?php
/**
 * 微信带参数二维码生成
 * @author Administrator
 *
 */

namespace Home\Controller;

use Think\Controller;

class QrcodeController extends Controller
{
    public $jssdk_obj;
    public $wx_api;
    //微信二维码生成接口URL
    static $qrcode_url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?";

    function __construct()
    {
        parent::__construct();
        $this->jssdk_obj = new \Org\Weixin\Jssdk();
        $this->wx_api    = new \Org\Weixin\WxApi();
    }

    //生成二维码
    public function index()
    {
        //提交数据
        if (!empty($_POST)) {
            $sceneStr = trim($_POST['scene']);
            $desc     = trim($_POST['desc']);
            if (empty($sceneStr)) {
                $arr = array(
                    'status' => "500",
                    'info'   => "出错了,请稍后再次尝试!"
                );
                echo json_encode($arr, 320);
                exit;
            }
            //此处获取token
            $ACCESS_TOKEN = $this->wx_api->getToken();
            $type         = 1; //1表示生成永久二维码URL
            $url          = $this->getQrcodeurl($ACCESS_TOKEN, $sceneStr, $type);
            //如果微信二维码生成
            if ($url) {
                //入库记录二维码生成记录
                $model              = M('plugin_weixin_dev_qrcode');
                $data['scene_str']  = $sceneStr;
                $data['desc']       = $desc;
                $data['url']        = $url;
                $data['createdate'] = time();
                $cid                = $model->add($data);
                //判断入库情况 给前台页面展示结果
                if ($cid) {
                    $arr = array(
                        'status' => "200",
                        'info'   => $url
                    );
                    echo json_encode($arr, 320);
                    exit;
                } else {
                    $arr = array(
                        'status' => "500",
                        'info'   => "出错了,请稍后再次尝试!"
                    );
                    echo json_encode($arr, 320);
                    exit;
                }
            }
            $this->display('qrcode');
        }
        //加载微信二维码设置模板
        $this->display('qrcode');
    }

    /**
     * 获取微信带参数二维码URL
     * @param unknown $ACCESS_TOKEN token
     * @param unknown $sceneStr 场景字符串
     * @param unknown $type 时间类型(永久:1)
     */
    protected function getQrcodeurl($ACCESS_TOKEN, $sceneStr, $type = 1)
    {
        $url = self::$qrcode_url . 'access_token=' . $ACCESS_TOKEN;
        if ($type == 1) {
            $arr = array(
                'action_name' => "QR_LIMIT_STR_SCENE",
                'action_info' => array(
                    'scene' => array(
                        'scene_str' => $sceneStr
                    )
                )
            );
            //生成永久二维码
            $qrcode = json_encode($arr);
        } else {
            $arr = array(
                'expire_seconds' => "1800",
                'action_name'    => "QR_STR_SCENE",
                'action_info'    => array(
                    'scene' => array(
                        'scene_str' => $sceneStr
                    )
                )
            );
            //生成临时二维码
            $qrcode = json_encode($arr);
        }
        $result = $this->http_post_data($url, $qrcode);
        $oo     = json_decode($result[1]);
        file_put_contents("gu_log.txt", "result:" . var_export($oo, TRUE) . "  \r\n\r\n", FILE_APPEND);
        if (!$oo->url) {
            //获取微信ticket失败  给页面错误提示
            $arr = array(
                'status' => "500",
                'info'   => "出错了,请稍后再次尝试!"
            );
            echo json_encode($arr, 320);
            exit;
        }
        $url = $oo->url;
        //file_put_contents("gu_log.txt", "urlRes:".var_export($url,TRUE)."  \r\n\r\n", FILE_APPEND);
        return $url;
    }

    /**
     * 微信接口提交
     * @param unknown $ACCESS_TOKEN token
     * @param unknown $sceneStr 场景字符串
     * @param unknown $type 时间类型(永久:1)
     */
    protected function http_post_data($url, $data_string)
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length: ' . strlen($data_string))
        );
        ob_start();
        curl_exec($ch);
        if (curl_errno($ch)) {
            $this->ErrorLogger('curl falied. Error Info: ' . curl_error($ch));
        }
        $return_content = ob_get_contents();
        ob_end_clean();
        $return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        return array($return_code, $return_content);
    }

}



