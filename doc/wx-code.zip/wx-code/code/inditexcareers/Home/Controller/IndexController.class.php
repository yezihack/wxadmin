<?php
/**
 * 公众号事件
 * @author Administrator
 *
 */

namespace Home\Controller;

use Think\Controller;

define("TOKEN", C("check_token"));

class IndexController extends Controller
{
    public $jssdk_obj;
    public $wx_api;

    public function __construct()
    {
        $this->responseMsg();
    }

    //微信回复消息
    public function responseMsg()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

        //非法验证
        $checkFlag = $this->checkSignature();
        if (!$checkFlag) {
            exit;
        }
        //首次验证
        if (empty($postStr)) {
            echo isset($_GET['echostr']) ? $_GET['echostr'] : '';
            exit;
        }

        //extract post data
        if (!empty($postStr)) {
            libxml_disable_entity_loader(true);
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);

            $fromUsername = $postObj->FromUserName;
            $toUsername   = $postObj->ToUserName;
            $keyword      = trim($postObj->Content);
            $msgType      = $postObj->MsgType;
            $Event        = $postObj->Event;
            $EventKey     = $postObj->EventKey;
            $time         = time();

            $textTpl
                = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";
            //关注事件
            if ((isset($msgType) && $msgType == 'event' && $Event == 'subscribe')) {
                //扫描带参数二维码事件
                if (isset($EventKey) && strpos($EventKey, 'qrscene_') !== false) {
                    //事件KEY值，qrscene_为前缀，后面为二维码的参数值
                    $scene_str = substr($EventKey, 8);
                    $this->add_qrcode_scan($fromUsername, $scene_str);
                } else {
                    $scene_str = 'noscan';
                    $this->add_qrcode_scan($fromUsername, $scene_str);
                }
                echo $this->subscribe_msg($fromUsername, $toUsername);
            } elseif ((isset($msgType) && $msgType == 'event' && $Event == 'SCAN')) {//最佳雇主图文回复
                //事件KEY值，是一个32位无符号整数，即创建二维码时的二维码scene_id
                $scene_str = $EventKey;
                $this->add_qrcode_scan($fromUsername, $scene_str);
            } else if ((isset($msgType) && $msgType == 'event' && $EventKey == 'button_employer')) {//扫描带参数二维码事件,用户已关注时的事件推送
                echo $this->best_employer_msg($fromUsername, $toUsername);

            } else if (!empty($keyword)) {//关键词回复
                switch ($keyword) {
                    case '一键投递':
                        echo $this->apply_msg($fromUsername, $toUsername);
                        break;
                    case '管培生':
                        echo $this->guanpei_msg($fromUsername, $toUsername);
                        break;
                    case '兼职生':
                        echo $this->jz_msg($fromUsername, $toUsername);
                        break;
                    default:
                        echo $this->_weixin_msg($fromUsername, $toUsername, 'text', "如有问题，欢迎直接回复“Q+ 你的问题”，我们会尽快回复~");
                        break;
                }
            }
            exit;

        } else {
            echo "";
            exit;
        }
    }

    /**
     * 关键词(一键投递)回复文本消息
     * @param unknown $fromUsername
     * @param unknown $toUsername
     */
    public function apply_msg($fromUsername, $toUsername)
    {
        $text = "热爱时尚行业的你，一键申请，<a href='https://www.inditexcareers.cn/'>即刻点击</a>，！";
        return $this->_weixin_msg($fromUsername, $toUsername, 'text', $text);
    }

    /**
     * 关键词(管培生)回复文本消息
     * @param unknown $fromUsername
     * @param unknown $toUsername
     */
    public function guanpei_msg($fromUsername, $toUsername)
    {
        $text = "查看应届生的招聘信息，<a href='https://mp.weixin.qq.com/s/TCg1xzlfBhN8YsCHjjpEpw'>即刻点击</a>！";
        return $this->_weixin_msg($fromUsername, $toUsername, 'text', $text);
    }

    /**
     * 关键词(兼职生)回复文本消息
     * @param unknown $fromUsername
     * @param unknown $toUsername
     */
    public function jz_msg($fromUsername, $toUsername)
    {
        $text = "查看学生兼职的招聘信息，<a href='https://mp.weixin.qq.com/s/5saTZqcVGSY9maMhepxlcA'>即刻点击</a>！";
        return $this->_weixin_msg($fromUsername, $toUsername, 'text', $text);
    }

    /**
     * 微信关注回复文本消息
     * @param unknown $fromUsername
     * @param unknown $toUsername
     */
    public function subscribe_msg($fromUsername, $toUsername)
    {
        $content   = "感谢关注Inditex Careers 官方招聘微信公众号，诚挚欢迎热爱时尚的你，加入Inditex集团，请点击底部菜单，了解集团&招聘相关热门资讯。" . PHP_EOL . PHP_EOL . "或通过回复以下“关键词”，及时获得索引信息：" . PHP_EOL . "回复“一键投递”，获取热招岗位的招聘信息" . PHP_EOL . "回复“管培生”，获取应届生的招聘信息" . PHP_EOL . "回复“兼职生”，获取学生兼职的招聘信息" . PHP_EOL . "更多问题，欢迎直接回复“Q+ 你的问题”，我们会尽快回复~";
        $resultStr = $this->_weixin_msg($fromUsername, $toUsername, 'text', $content);
        echo $resultStr;
    }

    /**
     * 微信回复消息
     * @param unknown $textTpl
     * @param unknown $fromUsername
     * @param unknown $toUsername
     * @param unknown $time
     * @param unknown $type
     * @param unknown $content
     */
    public function _weixin_msg($fromUsername, $toUsername, $type, $content)
    {
        $msg = "";
        switch ($type) {
            case 'text':
                $msg = $this->_weixin_text_msg($fromUsername, $toUsername, $content);
                break;
            case 'textPic':
                $msg = $this->_weixin_textpic_msg($fromUsername, $toUsername, $content);
                break;
            default:
                $msg = $this->_weixin_text_msg($fromUsername, $toUsername, $content);
                break;
        }
        return $msg;
    }

    /**
     * 微信回复文本消息
     * @param unknown $textTpl
     * @param unknown $fromUsername
     * @param unknown $toUsername
     * @param unknown $time
     * @param unknown $content
     */
    public function _weixin_text_msg($fromUsername, $toUsername, $content)
    {
        $textTpl
                   = '<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[%s]]></MsgType>
<Content><![CDATA[%s]]></Content>
</xml>';
        $time      = time();
        $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, 'text', $content);
        return $resultStr;
    }

    /**
     * 微信回复图文消息
     * @param unknown $textTpl
     * @param unknown $fromUsername
     * @param unknown $toUsername
     * @param unknown $time
     * @param unknown $content
     */
    public function _weixin_textpic_msg($fromUsername, $toUsername, $content_items)
    {
        $articleCount = count($content_items);

        $items_xml = "";
        foreach ($content_items as $content_item) {
            $items_xml
                .= "
            <item>
            <Title><![CDATA[{$content_item['title']}]]></Title>
            <Description><![CDATA[{$content_item['desc']}]]></Description>
            <PicUrl><![CDATA[{$content_item['picUrl']}]]></PicUrl>
            <Url><![CDATA[{$content_item['url']}]]></Url>
            </item>";
        }


        $textPic
                   = "<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[news]]></MsgType>
<ArticleCount>%s</ArticleCount>
<Articles>
%s
</Articles>
</xml>";
        $time      = time();
        $resultStr = sprintf($textPic, $fromUsername, $toUsername, $time, $articleCount, $items_xml);
        return $resultStr;
    }

    /**
     * 渠道统计
     * @param unknown $fromUsername 微信的openid
     * @param unknown $scene_str
     */
    public function add_qrcode_scan($fromUsername, $scene_str)
    {
        if (empty($fromUsername) || empty($scene_str)) {
            return 0;
        }

        //根据open_id查询扫描二维码记录
        $model            = M('plugin_weixin_dev_qrcode_scan');
        $qrcode_scan_info = $model->where(array('open_id' => "{$fromUsername}"))->find();

        $status = 1;
        //如果已经扫描过，则status设置为-1，本次扫描无效
        if (!empty($qrcode_scan_info)) {
            $status = -1;
        }

        $data['open_id']    = "{$fromUsername}";
        $data['scene_str']  = "{$scene_str}";
        $data['createdate'] = time();
        $data['status']     = $status;
        $model->add($data);
    }

    /**
     * 最佳雇主图文回复
     * @param $fromUsername
     * @param $toUsername
     * @return string
     */
    public function best_employer_msg($fromUsername, $toUsername)
    {
        $content_items = array(
            array(
                'title'  => 'INDITEX，一家有温度的公司',
                'desc'   => '2017雇主大奖的背后',
                'picUrl' => MAX_STATIC_URL . 'img/inditexcareers/best-two.jpg',
                'url'    => 'http://mp.weixin.qq.com/s/9mSkFCV7n7pxmD0fycIc4g',
            ),
            array(
                'title'  => '时尚帝国低调成就非凡雇主',
                'desc'   => 'INDITEX CHINA荣获2016各项雇主品牌年度大奖',
                'picUrl' => MAX_STATIC_URL . 'img/inditexcareers/best-one.jpg',
                'url'    => 'https://mp.weixin.qq.com/s/uMd7OZWkMPSQjU1CpTXq1g',
            ),
        );
        $resultStr     = $this->_weixin_msg($fromUsername, $toUsername, 'textPic', $content_items);
        return $resultStr;
    }


    public function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce     = $_GET["nonce"];

        $token  = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);

        if ($tmpStr == $signature) {
            return true;
        } else {
            return false;
        }
    }
}



