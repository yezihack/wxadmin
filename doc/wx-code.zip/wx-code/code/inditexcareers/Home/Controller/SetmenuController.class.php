<?php
/**
 * 公众号
 * @author Administrator
 *
 */
namespace Home\Controller;
use Think\Controller;

class SetmenuController extends Controller
{
    public $jssdk_obj;
    public $wx_api;

    public function __construct()
    {
        parent::__construct();
        $this->jssdk_obj = new \Org\Weixin\Jssdk();
        $this->wx_api = new \Org\Weixin\WxApi();
    }

    public function index()
    {
        $postData = '{
            "button": [
                {
                    "name": "了解",
                    "sub_button": [
                        {
                            "type": "view",
                            "name": "最In的历程",
                            "url": "https://mp.weixin.qq.com/s/Wxut20_NsK73hma6RUHE2g"
                        },
                        {
                            "type": "view",
                            "name": "最In的品牌",
                            "url": "https://mp.weixin.qq.com/s/j-VcBPxxbF6MIQMrHWnL4Q"
                        },
                       {
                            "type": "view",
                            "name": "最In的团队",
                            "url": "https://mp.weixin.qq.com/s/sajCIaLX7iv9USMQ3uMhdA"
                        }
                    ]
                },
                {
                    "name": "互动",
                    "sub_button": [
                       {
                            "type": "click",
                            "name": "最佳雇主",
                            "key": "button_employer"
                        },
                       {
                            "type": "view",
                            "name": "北京TC活动",
                            "url": "http://q.pincn.com/inditexcareers/openday"
                        },
                        {
                            "type": "view",
                            "name": "微博",
                            "url": "http://weibo.com/u/6034438868"
                        }
                    ]
                },
                {
                    "name": "加入",
                    "sub_button": [
                       {
                            "type": "view",
                            "name": "一键投递",
                            "url": "https://www.inditexcareers.cn/"
                        },
                        {
                            "type": "view",
                            "name": "管理培训生",
                            "url": "https://mp.weixin.qq.com/s/TCg1xzlfBhN8YsCHjjpEpw"
                        },
                        {
                            "type": "view",
                            "name": "兼职生",
                            "url": "https://mp.weixin.qq.com/s/5saTZqcVGSY9maMhepxlcA"
                        },
                        {
                            "type": "view",
                            "name": "官方网站",
                            "url": "https://www.inditexcareers.com/"
                        }
                    ]
                }
            ]
        }';

        # 获取token（实时获取，防止过期）
        $access_token = $this->wx_api->getToken();

        $postLen = strlen($postData);
        $header = array('Content-Type:application/json','Content-Length:'.$postLen);
        $url  = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$access_token;

        # 发送推送
        $res = $this ->wx_api->postInterface($url,$postData,$header);
        var_dump($res);
        exit;
    }

}



